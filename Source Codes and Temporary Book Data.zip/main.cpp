#include <iostream>
#include <conio.h>//for console if any
#include <fstream>//for file i/o stream
#include <sstream>//string stream for string to int conversion
#include <string>// manipulation with string
#include <stdlib.h>//for using printf function
#include <iomanip>//for setw function
#include <sys/types.h>//for
#include <sys/stat.h>//using
#include <unistd.h>//mkdir function
#include <windows.h>//for fetching the current UserName
#include <Lmcons.h>

using namespace std;

class stock
{
public:
    static int usr;
    static char* bd;
    static char* bs;
    static char* rnm;
    static char* rnmf;
    static char* t;
    struct book //for working with the file details
    {
        string author;
        string title;
        float price;
        string publisher;
        int stock;
    };

    static void enter()
    {
        //entering the details
        cout<<endl;
        string a,t,pub;
        float p;
        int stk;
       ofstream ofs(stock::bd, ios::app);
       cout<<"Enter Book Author: ";
       fflush(stdin);
       getline(cin,a);
       cout<<"Enter Book Title: ";
       fflush(stdin);
       getline(cin,t);
       cout<<"Enter the Price: ";
       cin>>p;
       cout<<"Enter Book Publisher: ";
       fflush(stdin);
       getline(cin,pub);
       cout<<"Enter the Stock: ";
       cin>>stk;
       ofs<<a<<","<<t<<","<<p<<","<<pub<<","<<stk<<'\n';
       cout<<"Book Added Succesfully"<<endl;

        //adding number of book entries
        ifstream nifs(stock::bs);
        getline(nifs,a);
        ofstream nofs(stock::bs);
        nifs>>a;
        stringstream num(a);
        num>>p;
        p++;
        nofs<<p;
        cout<<"Total Books: "<<p<<"\n\n"<<endl;
    }

    static void purchase()
    {
        //updating the structure for dealing with operations
        int i,n,j;
        string s,t;
        ifstream nifs(stock::bs);
        nifs>>s;
        nifs.close();
        stringstream num(s);
        num>>n;
        struct book bk[n];
        ifstream nfs(stock::bd);
        for(i=0;i<n;i++)
        {
            getline(nfs,s);//storing in s variable
            j=s.rfind(',');//find the last pos of _
            stringstream str(s.substr(j+1));
            str>>bk[i].stock;
            s=s.substr(0,j);
            j=s.rfind(',');
            bk[i].publisher=s.substr(j+1);
            s=s.substr(0,j);
            j=s.rfind(',');
            string a=s.substr(j+1);
            bk[i].price= std::stof(a);
            s=s.substr(0,j);
            j=s.rfind(',');
            bk[i].title=s.substr(j+1);
            s=s.substr(0,j);
            bk[i].author=s;
        }
        cout<<endl;
        nfs.close();

        //accepting the searching details
        cout<<"Enter the Title: ";
        fflush(stdin);
        getline(cin,t);
        cout<<"Enter the Author: ";
        fflush(stdin);
        getline(cin,s);
        for(i=0;i<n;i++)
        {
            if((bk[i].title).compare(t)==0&&(bk[i].author).compare(s)==0)
            {
                cout<<"Author: "<<bk[i].author<<endl;
                cout<<"Title: "<<bk[i].title<<endl;
                cout<<"Price: "<<bk[i].price<<endl;
                cout<<"Publisher: "<<bk[i].publisher<<endl;
                    cout<<"Enter the number of copies you want: ";
                    cin>>j;
                    if(j<=bk[i].stock)
                    {
                        cout<<"Stock Available.\nTotal Cost: "<<j*bk[i].price<<"\nDo you want to proceed with the Purchase? (y/n): ";
                        char ch;
                        cin>>ch;
                        if(ch=='Y'||ch=='y')
                        {
                            cout<<"Purchase Succesful\n\n"<<endl;
                            bk[i].stock=bk[i].stock-j;

                            //changing the file with new details of stock after purchase
                            ofstream ofs(stock::t);
                            for(i=0;i<n;i++)
                                ofs<<bk[i].author<<","<<bk[i].title<<","<<bk[i].price<<","<<bk[i].publisher<<","<<bk[i].stock<<'\n';
                            ofs.close();
                            remove(stock::bd);
                            rename(stock::t,stock::bd);
                        }
                        return;
                    }
                    else
                    {
                        cout<<"Sorry! These many copies are not in stock\n\n"<<endl;
                        return;
                    }
            }
        }
        cout<<"There no record of such Book. Sorry!\n\n"<<endl;
    }

    static void complete_detail()
    {
        //updating the structure for dealing with operations
        int i,n,j;
        string s;
        ifstream nifs(stock::bs);
        nifs>>s;
        nifs.close();
        stringstream num(s);
        num>>n;
        struct book bk[n];
        ifstream nfs(stock::bd);
        for(i=0;i<n;i++)
        {
            getline(nfs,s);
            j=s.rfind(',');
            stringstream str(s.substr(j+1));
            str>>bk[i].stock;
            s=s.substr(0,j);
            j=s.rfind(',');
            bk[i].publisher=s.substr(j+1);
            s=s.substr(0,j);
            j=s.rfind(',');
            string a=s.substr(j+1);
            bk[i].price= std::stof(a);
            s=s.substr(0,j);
            j=s.rfind(',');
            bk[i].title=s.substr(j+1);
            s=s.substr(0,j);
            bk[i].author=s;
        }

        //printing the header
        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
        cout<<"|"<<"Author              |Title                    |Price     |Publisher                |Stock |"<<endl;

        for(i=0;i<n;i++)//for formatted display of the details
        {
            cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
            cout<<"|"<<bk[i].author<<setw(20-bk[i].author.length()+1);
            cout<<"|"<<bk[i].title<<setw(25-bk[i].title.length()+1)<<"|";
            printf("%-10.2f|",bk[i].price);
            cout<<bk[i].publisher<<setw(25-bk[i].publisher.length()+1)<<"|";
            printf("%-6d|\n",bk[i].stock);
        }
        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
        cout<<"\n\n"<<endl;
    }

    static void keyword()
    {
        //updating the structure for dealing with operations
        int i,n,j,ctr;
        string s;
        ifstream nifs(stock::bs);
        nifs>>s;
        nifs.close();
        stringstream num(s);
        num>>n;
        struct book bk[n];
        ifstream nfs(stock::bd);
        for(i=0;i<n;i++)
        {
            getline(nfs,s);
            j=s.rfind(',');
            stringstream str(s.substr(j+1));
            str>>bk[i].stock;
            s=s.substr(0,j);
            j=s.rfind(',');
            bk[i].publisher=s.substr(j+1);
            s=s.substr(0,j);
            j=s.rfind(',');
            string a=s.substr(j+1);
            bk[i].price= std::stof(a);
            s=s.substr(0,j);
            j=s.rfind(',');
            bk[i].title=s.substr(j+1);
            s=s.substr(0,j);
            bk[i].author=s;
        }

        cout<<"Enter the Keyword: ";
        fflush(stdin);
        getline(cin,s);
        ctr=0;
        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
        cout<<"|"<<"Author              |Title                    |Price     |Publisher                |Stock |"<<endl;
        for(i=0;i<n;i++)
            if(bk[i].title.find(s)!=-1||bk[i].author.find(s)!=-1||bk[i].publisher.find(s)!=-1)
            {
                cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                cout<<"|"<<bk[i].author<<setw(20-bk[i].author.length()+1);
                cout<<"|"<<bk[i].title<<setw(25-bk[i].title.length()+1)<<"|";
                printf("%-10.2f|",bk[i].price);
                cout<<bk[i].publisher<<setw(25-bk[i].publisher.length()+1)<<"|";
                printf("%6d|\n",bk[i].stock);
                ctr++;
            }
        if(ctr==0)
        {
            cout<<"\n--------------------------------------------------------------------------------------------\n"<<endl;
            cout<<"\n                                       NO RECORD FOUND                                      \n"<<endl;
            cout<<"\n--------------------------------------------------------------------------------------------\n"<<endl;
        }
        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
        cout<<"\n\n"<<endl;
        return;
    }

    static void others()
    {
        char ch;
        int ctr=0;
        string a;
        float f;
        int d;

        //updating the structure for dealing with operations
        int i,n,j;
        string s,t;
        ifstream nifs(stock::bs);
        nifs>>s;
        nifs.close();
        stringstream num(s);
        num>>n;
        struct book bk[n];
        ifstream nfs(stock::bd);
        for(i=0;i<n;i++)
        {
            getline(nfs,s);
            j=s.rfind(',');
            stringstream str(s.substr(j+1));
            str>>bk[i].stock;
            s=s.substr(0,j);
            j=s.rfind(',');
            bk[i].publisher=s.substr(j+1);
            s=s.substr(0,j);
            j=s.rfind(',');
            string a=s.substr(j+1);
            bk[i].price= std::stof(a);
            s=s.substr(0,j);
            j=s.rfind(',');
            bk[i].title=s.substr(j+1);
            s=s.substr(0,j);
            bk[i].author=s;
        }
        cout<<endl;
        nfs.close();
        do
        {
        //displaying sub-menu
        cout<<"a. Display All Books with Author Name 'Nark John'"<<endl;
        cout<<"b. Sort according to Price (Low to High)"<<endl;
        cout<<"c. Display not available Books"<<endl;
        cout<<"d. Display books whose name start with S"<<endl;
        cout<<"e. Display books of SChand Publisher"<<endl;
        cout<<"f. Display books of price between 100 to 500"<<endl;
        cout<<"g. Display all the books whose title is 10-20 characters"<<endl;
        cout<<"h. Exit Sub-menu"<<endl;
        cout<<"Enter your choice: ";
        cin>>ch;

        //enter switch case for the desired operation.
        switch (ch)
        {
            case 'a':   ctr=0;
                        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                        cout<<"|"<<"Author              |Title                    |Price     |Publisher                |Stock |"<<endl;
                        for(i=0;i<n;i++)
                        if((bk[i].author).compare("Nark John")==0)
                        {
                            cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                            cout<<"|"<<bk[i].author<<setw(20-bk[i].author.length()+1);
                            cout<<"|"<<bk[i].title<<setw(25-bk[i].title.length()+1)<<"|";
                            printf("%-10.2f|",bk[i].price);
                            cout<<bk[i].publisher<<setw(25-bk[i].publisher.length()+1)<<"|";
                            printf("%6d|\n",bk[i].stock);
                            ctr++;
                        }
                        if(ctr==0)
                        {
                            cout<<"\n--------------------------------------------------------------------------------------------\n"<<endl;
                            cout<<"\n                                       NO RECORD FOUND                                      \n"<<endl;
                            cout<<"\n--------------------------------------------------------------------------------------------\n"<<endl;
                        }
                        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                        cout<<"\n\n"<<endl;
                        break;

            case 'b':   for(i=0;i<n;i++)
                            for(j=i+1;j<n;j++)
                                if(bk[i].price>bk[j].price)
                                {
                                    //swapping author
                                    a=bk[i].author;
                                    bk[i].author=bk[j].author;
                                    bk[j].author=a;
                                    //swapping title
                                    a=bk[i].title;
                                    bk[i].title=bk[j].title;
                                    bk[j].title=a;
                                    //swapping price
                                    f=bk[i].price;
                                    bk[i].price=bk[j].price;
                                    bk[j].price=f;
                                    //swapping publisher
                                    a=bk[i].publisher;
                                    bk[i].publisher=bk[j].publisher;
                                    bk[j].publisher=a;
                                    //swapping stock
                                    d=bk[i].stock;
                                    bk[i].stock=bk[j].stock;
                                    bk[j].stock=d;
                                }


                        //printing the header
                        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                        cout<<"|"<<"Author              |Title                    |Price     |Publisher                |Stock |"<<endl;

                        for(i=0;i<n;i++)//for formatted display of the details
                        {
                            cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                            cout<<"|"<<bk[i].author<<setw(20-bk[i].author.length()+1);
                            cout<<"|"<<bk[i].title<<setw(25-bk[i].title.length()+1)<<"|";
                            printf("%-10.2f|",bk[i].price);
                            cout<<bk[i].publisher<<setw(25-bk[i].publisher.length()+1)<<"|";
                            printf("%6d|\n",bk[i].stock);
                        }
                        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                        cout<<"\n\n"<<endl;
                        break;
            case 'c':   ctr=0;
                        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                        cout<<"|"<<"Author              |Title                    |Price     |Publisher                |Stock |"<<endl;
                        for(i=0;i<n;i++)
                        if(bk[i].stock==0)
                        {
                            cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                            cout<<"|"<<bk[i].author<<setw(20-bk[i].author.length()+1);
                            cout<<"|"<<bk[i].title<<setw(25-bk[i].title.length()+1)<<"|";
                            printf("%-10.2f|",bk[i].price);
                            cout<<bk[i].publisher<<setw(25-bk[i].publisher.length()+1)<<"|";
                            printf("%6d|\n",bk[i].stock);
                            ctr++;
                        }
                        if(ctr==0)
                        {
                            cout<<"\n--------------------------------------------------------------------------------------------\n"<<endl;
                            cout<<"\n                                       NO RECORD FOUND                                      \n"<<endl;
                            cout<<"\n--------------------------------------------------------------------------------------------\n"<<endl;
                        }
                        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                        cout<<"\n\n"<<endl;
                        break;
            case 'd':   ctr=0;
                        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                        cout<<"|"<<"Author              |Title                    |Price     |Publisher                |Stock |"<<endl;
                        for(i=0;i<n;i++)
                        if(bk[i].title.at(0)=='s'||bk[i].title.at(0)=='S')
                        {
                            cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                            cout<<"|"<<bk[i].author<<setw(20-bk[i].author.length()+1);
                            cout<<"|"<<bk[i].title<<setw(25-bk[i].title.length()+1)<<"|";
                            printf("%-10.2f|",bk[i].price);
                            cout<<bk[i].publisher<<setw(25-bk[i].publisher.length()+1)<<"|";
                            printf("%6d|\n",bk[i].stock);
                            ctr++;
                        }
                        if(ctr==0)
                        {
                            cout<<"\n--------------------------------------------------------------------------------------------\n"<<endl;
                            cout<<"\n                                       NO RECORD FOUND                                      \n"<<endl;
                            cout<<"\n--------------------------------------------------------------------------------------------\n"<<endl;
                        }
                        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                        cout<<"\n\n"<<endl;
                        break;
            case 'e':   ctr=0;
                        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                        cout<<"|"<<"Author              |Title                    |Price     |Publisher                |Stock |"<<endl;
                        for(i=0;i<n;i++)
                        if((bk[i].publisher).compare("SChand")==0)
                        {
                            cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                            cout<<"|"<<bk[i].author<<setw(20-bk[i].author.length()+1);
                            cout<<"|"<<bk[i].title<<setw(25-bk[i].title.length()+1)<<"|";
                            printf("%-10.2f|",bk[i].price);
                            cout<<bk[i].publisher<<setw(25-bk[i].publisher.length()+1)<<"|";
                            printf("%6d|\n",bk[i].stock);
                            ctr++;
                        }
                        if(ctr==0)
                        {
                            cout<<"\n--------------------------------------------------------------------------------------------\n"<<endl;
                            cout<<"\n                                       NO RECORD FOUND                                      \n"<<endl;
                            cout<<"\n--------------------------------------------------------------------------------------------\n"<<endl;
                        }
                        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                        cout<<"\n\n"<<endl;
                        break;
            case 'f':   ctr=0;
                        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                        cout<<"|"<<"Author              |Title                    |Price     |Publisher                |Stock |"<<endl;
                        for(i=0;i<n;i++)
                        if(bk[i].price>=100&&bk[i].price<=500)
                        {
                            cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                            cout<<"|"<<bk[i].author<<setw(20-bk[i].author.length()+1);
                            cout<<"|"<<bk[i].title<<setw(25-bk[i].title.length()+1)<<"|";
                            printf("%-10.2f|",bk[i].price);
                            cout<<bk[i].publisher<<setw(25-bk[i].publisher.length()+1)<<"|";
                            printf("%6d|\n",bk[i].stock);
                            ctr++;
                        }
                        if(ctr==0)
                        {
                            cout<<"\n--------------------------------------------------------------------------------------------\n"<<endl;
                            cout<<"\n                                       NO RECORD FOUND                                      \n"<<endl;
                            cout<<"\n--------------------------------------------------------------------------------------------\n"<<endl;
                        }
                        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                        cout<<"\n\n"<<endl;
                        break;
            case 'g':   ctr=0;
                        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                        cout<<"|"<<"Author              |Title                    |Price     |Publisher                |Stock |"<<endl;
                        for(i=0;i<n;i++)
                        if((bk[i].title).length()>=10&&(bk[i].title).length()<=20)
                        {
                            cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                            cout<<"|"<<bk[i].author<<setw(20-bk[i].author.length()+1);
                            cout<<"|"<<bk[i].title<<setw(25-bk[i].title.length()+1)<<"|";
                            printf("%-10.2f|",bk[i].price);
                            cout<<bk[i].publisher<<setw(25-bk[i].publisher.length()+1)<<"|";
                            printf("%6d|\n",bk[i].stock);
                            ctr++;
                        }
                        if(ctr==0)
                        {
                            cout<<"\n--------------------------------------------------------------------------------------------\n"<<endl;
                            cout<<"\n                                       NO RECORD FOUND                                      \n"<<endl;
                            cout<<"\n--------------------------------------------------------------------------------------------\n"<<endl;
                        }
                        cout<<"+--------------------+-------------------------+----------+-------------------------+------+"<<endl;
                        cout<<"\n\n"<<endl;
                        break;
            case 'h':   cout<<endl;
                        return;
            default:    cout<<"Invalid Input. Please Enter your choice in small letters only.\n"<<endl;
        }
        }while(true);
    }

    static void update_pass()
    {
        string temp,p,s;
        ifstream ifs(stock::rnmf);
        getline(ifs,s);
        cout<<"Enter New Password for user: ";
        fflush(stdin);
        getline(cin,p);
        for(int i=0;i<p.length();i++)
            temp+=char(p.at(i)+100);
        p=temp;
        ofstream ofs(stock::rnmf);
        ofs<<s<<'\n'<<p;
        cout<<"Password Set Succesfully\n"<<endl;
        ifs.close();
        ofs.close();
    }

    static void update_record()
    {
        //updating the structure for dealing with operations
        int i,n,j;
        char ch;
        string s,t;
        ifstream nifs(stock::bs);
        nifs>>s;
        nifs.close();
        stringstream num(s);
        num>>n;
        struct book bk[n];
        ifstream nfs(stock::bd);
        for(i=0;i<n;i++)
        {
            getline(nfs,s);//storing in s variable
            j=s.rfind(',');//find the last pos of _
            stringstream str(s.substr(j+1));
            str>>bk[i].stock;
            s=s.substr(0,j);
            j=s.rfind(',');
            bk[i].publisher=s.substr(j+1);
            s=s.substr(0,j);
            j=s.rfind(',');
            string a=s.substr(j+1);
            bk[i].price= std::stof(a);
            s=s.substr(0,j);
            j=s.rfind(',');
            bk[i].title=s.substr(j+1);
            s=s.substr(0,j);
            bk[i].author=s;
        }
        cout<<endl;
        nfs.close();

        //accepting the searching details
        cout<<"Enter the Title: ";
        fflush(stdin);
        getline(cin,t);
        cout<<"Enter the Author: ";
        fflush(stdin);
        getline(cin,s);

        for(i=0;i<n;i++)
        {
            if((bk[i].title).compare(t)==0&&(bk[i].author).compare(s)==0)
            {
                while(true)
                {
                    cout<<"1. Update Price\n2. Update Stock\n3. Save and Exit\nEnter your Choice: ";
                    cin>>ch;
                    if(ch=='1')
                    {
                        cout<<"Enter the Price: ";
                        cin>>bk[i].price;
                    }
                    else if(ch=='2')
                    {
                        cout<<"Enter the Stock: ";
                        int n;
                        cin>>n;
                        bk[i].stock+=n;

                    }
                    else if(ch=='3')
                    {
                        //changing the file with new details of stock after purchase
                        ofstream ofs(stock::t);
                        for(i=0;i<n;i++)
                            ofs<<bk[i].author<<","<<bk[i].title<<","<<bk[i].price<<","<<bk[i].publisher<<","<<bk[i].stock<<'\n';
                        ofs.close();
                        remove(stock::bd);
                        rename(stock::t,stock::bd);
                        return;
                    }
                    else
                        cout<<"Invalid Choice";
                }
            }
            else
                cout<<"No Record Found\n"<<endl;
        }
    }

    static void engine()
    {
        char ch;
        do
        {
        cout<<"MENU OF OPERATIONS"<<endl;
        if(stock::usr==1)
        {
            cout<<"1. Enter a Book Detail\n2. Update Record\n3. Change User Password\n4. Redirect-to Book-Store"<<endl;
            cout<<"5. Exit the Store\n"<<"Enter your choice: ";
            cin>>ch;
            switch(ch)
            {
                case '1': enter();
                        break;
                case '2': update_record();
                        break;
                case '3': update_pass();
                        break;
                case '4': stock::usr=2;
                        break;
                case '5': cout<<"------------------------------------------------"<<endl;
                        cout<<"                   THANK YOU                   "<<endl;
                        cout<<"------------------------------------------------"<<endl;
                        return;
                default: cout<<"Invalid Choice. Choose Again.\n"<<endl;
            }
        }
        else
        {
            cout<<"1. Purchase a Book\n2. Details for all Book\n3. Keyword Search\n4. Others"<<endl;
            cout<<"5. Exit the Store\n"<<"Enter your choice: ";
            fflush(stdin);
            cin>>ch;
            switch(ch)
            {
                case '1': purchase();
                            break;
                case '2': complete_detail();
                            break;
                case '3': keyword();
                            break;
                case '4': others();
                            break;
                case '5': cout<<"------------------------------------------------"<<endl;
                        cout<<"                   THANK YOU                   "<<endl;
                        cout<<"------------------------------------------------"<<endl;
                        return;
                default: cout<<"Invalid Choice. Choose Again.\n"<<endl;
            }
        }
        cout<<endl;
        }while(true);
    }

    static void setpath()
    {
        char * userpath = getenv("USERPROFILE");
        char * a;
        string path;
        path = string(userpath) + "\\Documents\\Athsovin";
        userpath = new char[path.length()+1];
        copy(path.begin(),path.end(),userpath);
        userpath[path.length()]='\0';

        int check=mkdir(userpath);

        path=string(userpath) +"\\log.dat";
        a=new char[path.length()+1];
        copy(path.begin(),path.end(),a);
        a[path.length()]='\0';
        stock::rnm=a;

        path=string(userpath)+"\\log.txt";
        a=new char[path.length()+1];
        copy(path.begin(),path.end(),a);
        a[path.length()]='\0';
        stock::rnmf=a;

        path=string(userpath)+"\\Book Detail.csv";
        a=new char[path.length()+1];
        copy(path.begin(),path.end(),a);
        a[path.length()]='\0';
        stock::bd=a;

        path=string(userpath)+"\\Book Stock.txt";
        a=new char[path.length()+1];
        copy(path.begin(),path.end(),a);
        a[path.length()]='\0';
        stock::bs=a;

        path=string(userpath)+"\\temp.txt";
        a=new char[path.length()+1];
        copy(path.begin(),path.end(),a);
        a[path.length()]='\0';
        stock::t=a;
    }

};

int main()
{
    string s,p,temp="",temp1="";
    int i,ctr=0,h;
    stock::setpath();
    rename(stock::rnm,stock::rnmf);
    ifstream ifs(stock::rnmf);
    getline(ifs,s);
    ifs.close();
    if(s.compare("")==0)
    {
        while(true)
        {
            cout<<"Set Username: ";
            fflush(stdin);
            getline(cin,s);
            if(string("admin").compare(s)!=0)
                break;
            cout<<"Permission denied. User already exists."<<endl;
        }
        cout<<"Set Password: ";
        fflush(stdin);
        getline(cin,p);
        for(i=0;i<s.length();i++)
            temp+=char(s.at(i)+100);
        s=temp;
        temp="";
        for(i=0;i<p.length();i++)
            temp+=char(p.at(i)+100);
        p=temp;
        ofstream ofs(stock::rnmf);
        ofs<<s<<'\n'<<p;
        cout<<"Password Set Succesfully\n"<<endl;
        stock::usr=1;
    }
    else
    {
        ifstream ifs(stock::rnmf);
        getline(ifs,temp);
        getline(ifs,temp1);
        for(i=0;i<temp.length();i++)
            temp.at(i)=char(temp.at(i)-100);
        for(i=0;i<temp1.length();i++)
            temp1.at(i)=char(temp1.at(i)-100);
        char a[20];//char a[temp1.length()];
        do
        {
        cout<<"Enter Username: ";
        fflush(stdin);
        getline(cin,s);
        cout<<"Enter Password: ";
        p="";
        i=0;
        while(true)//for printing asterisk in password input
        {
            a[i]=getch();
            if(a[i]==8)
            {
                p=p.substr(0,p.length()-1);
                continue;
            }
            if(a[i]<32)
                break;
            p+=a[i];
            cout<<'*';
        }
        cout<<endl;

        if(string("admin").compare(s)==0)
            h=1;
        else if(temp.compare(s)==0)
            h=2;
        else
            h=3;
        switch(h)
        {
            case 1: if(string("admin").compare(p)==0)
                    {
                        cout<<"Login Successful. Press any key to continue.";
                        getch();
                        ctr=4;
                        stock::usr=1;
                    }
                    else
                    {
                        cout<<"Password Not Matched\n"<<endl;
                        ctr++;
                    }
                    break;
            case 2: if(temp1.compare(p)==0)
                    {
                        cout<<"Login Successful. Press any key to continue.";
                        getch();
                        ctr=4;
                        stock::usr=2;
                    }
                    else
                    {
                        cout<<"Password Not Matched\n"<<endl;
                        ctr++;
                    }
                    break;
            case 3: cout<<"User not found\n"<<endl;
                    ctr++;
        }

        ifs.close();
        }while(ctr<3);
    }
    if(ctr==3)
    {
        cout<<"Login Failed 3 Times, Program Terminated";
        return 0;
    }
    cout<<"\n\nLOADING";
    for(i=0;i<20;i++)
    {
        cout<<'.';
        Sleep(200);
    }
    cout<<endl;
    system("cls");
    cout<<"    _  _____ _   _ ____   _____     _____ _   _"<<endl;
    cout<<"   / \\|_   _| | | / ___| / _ \\ \\   / /_ _| \\ | |"<<endl;
    cout<<"  / _ \\ | | | |_| \\___ \\| | | \\ \\ / / | ||  \\| |"<<endl;
    cout<<" / ___ \\| | |  _  |___) | |_| |\\ V /  | || |\\  |"<<endl;
    cout<<"/_/   \\_\\_| |_| |_|____/ \\___/  \\_/  |___|_| \\_|"<<endl;
    cout<<"------------------------------------------------"<<endl;
    cout<<"                   BOOK STORE                  "<<endl;
    cout<<"------------------------------------------------"<<endl;


    stock::engine();
    rename(stock::rnmf,stock::rnm);
    return 0;

}

char* stock::bd;
char* stock::bs;
char* stock::rnm;
char* stock::rnmf;
char* stock::t;
int stock::usr;
